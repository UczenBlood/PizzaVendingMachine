interface Beeps {
	void sound();
}