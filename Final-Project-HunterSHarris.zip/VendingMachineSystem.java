import java.util.*;

class VendingMachineSystem  implements Beeps{
	
	ArrayList<String> startUpList = new ArrayList<String>();

	
	public VendingMachineSystem() {
			startUpList.add("-----------------------------------------------");
			startUpList.add("Hello, how may I serve you today?");
			startUpList.add("-----------------------------------------------");
		
	}
	public void startUp(){
		for (int i = 0; i < startUpList.size(); i++) {
			System.out.println(startUpList.get(i));
		}
	}
@Override
public void sound(){
	System.out.println("bbeeeeppp! bboooooopppp!!");
}

}