import java.util.*;

//import java.util.*;
class Main {
  public static void main(String[] args) {
    // this does the start up and welcome message
    VendingMachineSystem vMS = new VendingMachineSystem();
    Pizza pizza = new Pizza();
    Scanner sc = new Scanner(System.in);
    Calc cal = new Calc();
    //this is the startup and asks if they want pizza
    vMS.sound();
    vMS.startUp();
    System.out.println(pizza.doYouWantFood());
    
    String firstAnswer = sc.nextLine();
    // asking if they want pizza or not
    do{
      switch(firstAnswer){
        case "yes":
        System.out.println("Fantastic!");
        break;
        case "no":
        System.out.println("welp that sucks, I only have pizza");
        break;
        default:
        System.out.println("not a valid input, try again");
      }
    } while(firstAnswer == "yes" || firstAnswer == "no");
    pizza.sound();
    System.out.println();
    // select product
    pizza.giveTheProducts();
    System.out.println();
    
    cal.startUp();
    int pizzaSelect = sc.nextInt();
    
//  cal.secletedPizza();
    
    System.out.println("you selected "+ pizza.pizzaList.get(pizzaSelect));
    cal.cost();
    System.out.println();
    cal.putInMoney();
    cal.bankaccount();
  
    

    // calculate money that was given
    System.out.println(cal.money);
    cal.canGet();
  }
  }