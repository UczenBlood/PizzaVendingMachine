import java.util.*;
class Calc extends VendingMachineSystem {
	Pizza pizza = new Pizza();
	double moneyInBank = Math.floor(Math.random() *500);
	String money = ("Your bankAccount has $"+ moneyInBank);
	ArrayList<String> lag = new ArrayList<String>();
	
	public Calc(){
		lag.add("................. seems to be some lag here.......");
		lag.add(".................loading bank info................");
		lag.add("...............still loading......................");
		lag.add("...........mmmm you must bank with slowmobank huh?");
		lag.add("wait!.... it's loaded! here's what in your account");
	}
	@Override
	public void startUp(){
		System.out.println("Select the number next to the pizza you would like?");
	}
	
	public void bankaccount(){
		for (int i = 0; i < lag.size(); i++) {
			try {
				Thread.sleep(1300);
			} catch (Exception e) {
				
			}
			System.out.println(lag.get(i));
		}
	}
	
void canGet(){
	if(moneyInBank > 81.5){
		System.out.println("You have enough money!");
		System.out.println(moneyInBank +" - 81.5, leaves you with $"+(moneyInBank - 81.5)+" in your bank account");
	} else if(moneyInBank == 81.5){
		System.out.println("you have just enough!");
		System.out.println(moneyInBank +" - 81.5, leaves you with $"+(moneyInBank - 81.5)+" in your bank account");
	}else{
		System.out.println("Looks like your broke, no pizza for you!");
	}
	
}
		
public void cost(){
	System.out.println("That will $81.5, yeah yeah I know it's a sweet deal!");
		}
public void putInMoney(){
System.out.println("Please scan your phone to complete your purchase");
	}
	
	@Override
	public void sound(){
		System.out.println("Thank you for your purchase!");
	}
	
	
}