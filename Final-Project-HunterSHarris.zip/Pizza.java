import java.util.*;

class Pizza extends VendingMachineSystem implements Beeps {
//Scanner sc = new Scanner(System.in);
	
	HashMap<Integer,String> pizzaList = new HashMap<Integer,String>();
	
public Pizza(){
	pizzaList.put(1,"Cheese Pizza");
	pizzaList.put(2,"Pepperoni Pizza");
	pizzaList.put(3,"Hawaiian Pizza");
	pizzaList.put(4,"Meat Lover's Pizza");
	pizzaList.put(5,"Veggie Lover's Pizza");
}
	
	
public String doYouWantFood(){
	return "Would you like to get a pizza? (yes/no)";
}
	

	public void giveTheProducts(){
		for(int x =1; x < pizzaList.size()+1 ;x++){
			System.out.println( x +" - "+pizzaList.get(x));}
}
	@Override
	public void sound(){
		System.out.println("It's pizza time!!!!");
	}

}